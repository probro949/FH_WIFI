package com.fhwifi.app

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    private lateinit var webView: WebView
    private val site = "https://fh-wlan.vercel.app/"
    private val instagram = "https://www.instagram.com/vvvu._4/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(7, 11, 22)
        window.navigationBarColor = android.graphics.Color.rgb(7, 11, 22)

        webView = WebView(this).apply {
            setBackgroundColor(android.graphics.Color.rgb(7, 11, 22))
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    return when {
                        uri.host == "fh-wlan.vercel.app" -> false
                        uri.toString().startsWith(instagram) -> {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(instagram)))
                            true
                        }
                        else -> true
                    }
                }

                override fun onPageFinished(view: WebView, url: String) {
                    super.onPageFinished(view, url)
                    applyRestyle()
                }
            }
        }
        setContentView(FrameLayout(this).apply {
            addView(webView, FrameLayout.LayoutParams(-1, -1))
        })
        if (savedInstanceState == null) webView.loadUrl(site) else webView.restoreState(savedInstanceState)
    }

    private fun applyRestyle() {
        val js = """(function() {
          const css = `
            html, body { min-height:100% !important; background: radial-gradient(circle at 50% 0%, #12345b 0%, #0a1428 38%, #060a14 100%) !important; color:#eef7ff !important; font-family:Arial,sans-serif !important; }
            body { margin:0 !important; padding:28px 16px 100px !important; box-sizing:border-box !important; }
            body * { box-sizing:border-box !important; }
            h1,h2,h3 { color:#f4fbff !important; text-align:center !important; }
            input { width:min(100%,420px) !important; min-height:50px !important; border:1px solid #267fb4 !important; border-radius:14px !important; background:#101d32 !important; color:#fff !important; padding:12px 15px !important; outline:none !important; }
            button, input[type=button], input[type=submit] { border:0 !important; border-radius:14px !important; min-height:48px !important; padding:12px 22px !important; background:linear-gradient(100deg,#0879d5,#35c8ed) !important; color:#03101d !important; font-weight:800 !important; box-shadow:0 8px 24px #0879d544 !important; cursor:pointer !important; }
            label, p, span { color:#dceeff !important; }
            a { color:#5ed7ff !important; }
            #fh-instagram { position:fixed; left:50%; bottom:18px; transform:translateX(-50%); z-index:2147483647; display:block; width:calc(100% - 36px); max-width:360px; padding:14px 18px; border-radius:15px; text-align:center; text-decoration:none; color:#fff !important; font-weight:800; background:linear-gradient(100deg,#833ab4,#e1306c,#f77737); box-shadow:0 8px 25px #0008; }
          `;
          let style = document.getElementById('fh-wifi-style');
          if (!style) { style = document.createElement('style'); style.id='fh-wifi-style'; document.head.appendChild(style); }
          style.textContent = css;
          function hideFeedbackText() {
            const nodes = Array.from(document.querySelectorAll('body *')).filter(el => el.children.length === 0);
            nodes.forEach(el => {
              const text = (el.textContent || '').replace(/\\s+/g, ' ').trim().toLowerCase();
              if (text.includes('is this helpful?') || text === 'click here') {
                let target = el;
                for (let i = 0; i < 4 && target.parentElement; i++) {
                  const parent = target.parentElement;
                  if (parent.matches('section, footer, article, [class*="feedback"], [id*="feedback"], [class*="helpful"], [id*="helpful"]')) {
                    target = parent;
                    break;
                  }
                  target = parent;
                }
                target.style.setProperty('display', 'none', 'important');
              }
            });
          }
          hideFeedbackText();
          if (!window.fhWifiFeedbackObserver) {
            window.fhWifiFeedbackObserver = new MutationObserver(hideFeedbackText);
            window.fhWifiFeedbackObserver.observe(document.body, {childList:true, subtree:true, characterData:true});
          }
          document.querySelectorAll('a[href]').forEach(a => {
            const href = a.href || '';
            if (href && !href.startsWith(location.origin) && !href.includes('instagram.com/vvvu._4')) a.style.display='none';
          });
          if (!document.getElementById('fh-instagram')) {
            const link = document.createElement('a');
            link.id='fh-instagram'; link.href='https://www.instagram.com/vvvu._4/';
            link.textContent='Instagram  @vvvu._4'; link.target='_blank';
            link.addEventListener('click', function(e) { e.preventDefault(); location.href='https://www.instagram.com/vvvu._4/'; });
            document.body.appendChild(link);
          }
        })();"""
        webView.evaluateJavascript(js, null)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        if (::webView.isInitialized) webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }
}
